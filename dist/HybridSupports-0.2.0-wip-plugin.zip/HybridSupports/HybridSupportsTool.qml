// Required Notice: Copyright Matthew Armstrong (https://github.com/The-Dorkknight)
// Licensed under the PolyForm Noncommercial License 1.0.0. No warranty.

import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

import UM 1.5 as UM
import Cura 1.1 as Cura

Item
{
    id: base
    width: column.width
    height: column.height

    readonly property int fieldWidth: Math.round(UM.Theme.getSize("setting_control").width * 0.45)
    readonly property int fieldHeight: UM.Theme.getSize("setting_control").height

    function prop(name) { return UM.Controller.properties.getValue(name) }
    function setNum(name, text) { UM.Controller.setProperty(name, text.replace(",", ".")) }

    Column
    {
        id: column
        spacing: UM.Theme.getSize("default_margin").height

        GridLayout
        {
            id: grid
            columns: 4
            columnSpacing: UM.Theme.getSize("default_margin").width
            rowSpacing: UM.Theme.getSize("narrow_margin").height

            UM.Label { text: "Head" }
            Grid
            {
                Layout.columnSpan: 3
                columns: 4
                columnSpacing: UM.Theme.getSize("default_margin").width
                Cura.RadioButton
                {
                    text: "Cone"
                    checked: prop("HeadMode") === "cone"
                    onClicked: UM.Controller.setProperty("HeadMode", "cone")
                }
                Cura.RadioButton
                {
                    text: "Branch"
                    checked: prop("HeadMode") === "branch"
                    onClicked: UM.Controller.setProperty("HeadMode", "branch")
                }
                Cura.RadioButton
                {
                    text: "Solid"
                    checked: prop("HeadMode") === "trapezoid"
                    onClicked: UM.Controller.setProperty("HeadMode", "trapezoid")
                }
                Cura.RadioButton
                {
                    text: "Conform"
                    checked: prop("HeadMode") === "conform"
                    onClicked: UM.Controller.setProperty("HeadMode", "conform")
                }
            }

            UM.Label { text: "Inside the cone"; visible: prop("HeadMode") === "cone" }
            Row
            {
                Layout.columnSpan: 3
                visible: prop("HeadMode") === "cone"
                spacing: UM.Theme.getSize("default_margin").width
                Cura.RadioButton
                {
                    text: "Cross"
                    checked: prop("ConeFill") === "cross"
                    onClicked: UM.Controller.setProperty("ConeFill", "cross")
                }
                Cura.RadioButton
                {
                    text: "Rings"
                    checked: prop("ConeFill") === "rings"
                    onClicked: UM.Controller.setProperty("ConeFill", "rings")
                }
                Cura.RadioButton
                {
                    text: "None"
                    checked: prop("ConeFill") === "none"
                    onClicked: UM.Controller.setProperty("ConeFill", "none")
                }
            }

            UM.Label { text: "Gussets (0 = off)" }
            UM.TextFieldWithUnit
            {
                Layout.preferredWidth: base.fieldWidth; height: base.fieldHeight
                unit: ""
                text: prop("GussetCount")
                onEditingFinished: setNum("GussetCount", text)
            }
            UM.Label { text: "Gusset height" }
            UM.TextFieldWithUnit
            {
                Layout.preferredWidth: base.fieldWidth; height: base.fieldHeight
                unit: "mm"
                enabled: prop("GussetCount") > 0
                text: prop("GussetHeight")
                onEditingFinished: setNum("GussetHeight", text)
            }

            UM.Label { text: "Gusset length" }
            UM.TextFieldWithUnit
            {
                Layout.preferredWidth: base.fieldWidth; height: base.fieldHeight
                unit: "mm"
                enabled: prop("GussetCount") > 0
                text: prop("GussetLength")
                onEditingFinished: setNum("GussetLength", text)
            }
            UM.Label { text: "Tube walls (lines)" }
            UM.TextFieldWithUnit
            {
                Layout.preferredWidth: base.fieldWidth; height: base.fieldHeight
                unit: ""
                text: prop("WallLines")
                onEditingFinished: setNum("WallLines", text)
            }

            UM.Label { text: prop("HeadMode") === "branch" ? "Gap between branches" : "Max bridge span" }
            UM.TextFieldWithUnit
            {
                Layout.preferredWidth: base.fieldWidth; height: base.fieldHeight
                unit: "mm"
                enabled: prop("HeadMode") === "cone" || prop("HeadMode") === "branch"
                text: prop("BridgeGap")
                onEditingFinished: setNum("BridgeGap", text)
            }
            UM.Label { text: "Contact Z gap" }
            UM.TextFieldWithUnit
            {
                Layout.preferredWidth: base.fieldWidth; height: base.fieldHeight
                unit: "mm"
                text: prop("ContactGap")
                onEditingFinished: setNum("ContactGap", text)
            }

            UM.Label { text: "Max tower radius" }
            UM.TextFieldWithUnit
            {
                Layout.preferredWidth: base.fieldWidth; height: base.fieldHeight
                unit: "mm"
                text: prop("MaxTowerRadius")
                onEditingFinished: setNum("MaxTowerRadius", text)
            }
            UM.Label { text: "Split spans over" }
            UM.TextFieldWithUnit
            {
                Layout.preferredWidth: base.fieldWidth; height: base.fieldHeight
                unit: "mm"
                text: prop("MaxSpan")
                onEditingFinished: setNum("MaxSpan", text)
            }

            UM.Label { text: "Overhang angle" }
            UM.TextFieldWithUnit
            {
                Layout.preferredWidth: base.fieldWidth; height: base.fieldHeight
                unit: "°"
                enabled: !prop("UseCuraAngle")
                text: prop("SupportAngle")
                onEditingFinished: setNum("SupportAngle", text)
            }
            UM.CheckBox
            {
                Layout.columnSpan: 2
                text: "Use Cura's angle"
                checked: prop("UseCuraAngle")
                onClicked: UM.Controller.setProperty("UseCuraAngle", checked)
            }

            UM.CheckBox
            {
                Layout.columnSpan: 4
                text: "Block Cura auto-support over towers"
                checked: prop("UseBlocker")
                onClicked: UM.Controller.setProperty("UseBlocker", checked)
            }
        }

        Row
        {
            spacing: UM.Theme.getSize("default_margin").width
            Cura.PrimaryButton
            {
                objectName: "hybridGenerate"
                text: "Generate"
                onClicked: UM.Controller.triggerAction("generateSupports")
            }
            Cura.SecondaryButton
            {
                objectName: "hybridRemove"
                text: "Remove"
                onClicked: UM.Controller.triggerAction("removeSupports")
            }
        }

        UM.Label
        {
            width: grid.width
            wrapMode: Text.WordWrap
            text: prop("Status")
        }

        UM.Label
        {
            width: grid.width
            wrapMode: Text.WordWrap
            text: prop("VersionText")
            font: UM.Theme.getFont("small")
            color: UM.Theme.getColor("text_medium")
        }
    }
}
