# Required Notice: Copyright Matthew Armstrong (https://github.com/The-Dorkknight)
# Licensed under the PolyForm Noncommercial License 1.0.0. No warranty.
"""Hybrid tower support geometry core.

Pure numpy, no Cura imports, so it can be tested and profiled on its own.
Coordinates are Z-up millimetres with the build plate at Z = 0. The Cura
adapter (HybridSupportsTool.py) converts from Cura's Y-up scene.

Pipeline per model (0.2):
  1. Overhang faces (flatter than the support angle) are cut into small pieces and
     sampled on an XY grid.
  2. Every sample casts a ray down to the surface it would stand on. Samples that are
     inside the model, or barely above a surface, are dropped.
  3. Samples are grouped into support regions by XY neighbourhood AND height, so a
     ceiling, a rib and a hinge at different heights stay separate even where they
     touch in plan view.
  4. Each region gets ONE trunk (a hollow tube) where the column below is clear and the
     reach to the far edge of the region is smallest. The trunk gets fatter as the
     reach grows.
  5. Branch head: thin wedge-shaped fins rise from the trunk at no more than 45 degrees
     and fan out until every part of the overhang is within half a bridge gap of a fin.
     (The older solid heads, "trapezoid" and "conform", are still available.)
  6. Trunk, gussets and fins are tested against the model and shortened where they
     would run into it, keeping Cura's support X/Y distance.
  7. A region too wide for its height to reach at 45 degrees is split in two, and so on.
  8. A thin anti-overhang blocker over each region keeps Cura's own automatic support
     from filling the same space.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np

__version__ = "0.2.0-wip"  # WORK IN PROGRESS: many features may be broken


# --------------------------------------------------------------------------
# Settings and results
# --------------------------------------------------------------------------

@dataclass
class HybridSettings:
    support_angle: float = 50.0      # deg from vertical, same meaning as Cura's
    head_mode: str = "cone"          # "cone" (hollow cone + rings), "branch" (slats), "trapezoid"/"conform" (solid)
    head_fraction: float = 0.20      # solid heads: the head takes at least this share of the gap
    max_flare_angle: float = 45.0    # deg from vertical for branches and head sides
    contact_gap: float = 0.2         # mm Z gap between the support top and the model
    line_width: float = 0.4          # support line width (mm)
    layer_height: float = 0.2
    wall_lines: int = 2              # trunk wall thickness in lines
    branch_lines: int = 3            # branch (fin) thickness in lines
    min_branch_thickness: float = 0.0  # raised by the Cura side when support walls are off
    tower_scale: float = 0.25        # trunk radius as a share of its reach
    min_tower_radius: float = 2.0    # mm (outer)
    max_tower_radius: float = 8.0    # mm (outer)
    cone_fill: str = "cross"         # inside the cone: "cross" (spokes), "rings" or "none"
    bridge_gap: float = 20.0         # longest bridge left for the printer (cross: spoke gaps, rings: spacing)
    low_gap: float = 6.0             # overhangs lower than this get standing webs, no trunk
    max_branches: int = 24
    max_span: float = 250.0          # regions wider than this are split; normally 1 pillar per region
    min_island_area: float = 1.0     # mm^2; smaller overhangs are ignored
    bed_tolerance: float = 0.3       # mm; surfaces this close to Z=0 count as the plate
    xy_clearance: float = 0.8        # sideways gap kept from the model (Cura's support X/Y distance)
    gusset_count: int = 4            # 0 disables gussets
    gusset_height: float = 6.0       # mm; capped at half the trunk height
    gusset_length: float = 5.0       # mm outward from the tube wall
    blocker: bool = True
    blocker_margin: float = 1.0      # mm XY margin around the region outline
    segments: int = 24               # tube / head resolution around the axis
    head_rings: int = 6              # conform head: radial sample rings


@dataclass
class Mesh:
    vertices: np.ndarray  # (N, 3) float
    faces: np.ndarray     # (M, 3) int

    @staticmethod
    def empty() -> "Mesh":
        return Mesh(np.zeros((0, 3)), np.zeros((0, 3), dtype=np.int64))

    @staticmethod
    def concat(meshes: List["Mesh"]) -> "Mesh":
        meshes = [m for m in meshes if len(m.faces)]
        if not meshes:
            return Mesh.empty()
        verts, faces, off = [], [], 0
        for m in meshes:
            verts.append(m.vertices)
            faces.append(m.faces + off)
            off += len(m.vertices)
        return Mesh(np.vstack(verts), np.vstack(faces))

    def volume(self) -> float:
        v = self.vertices[self.faces]
        return float(np.einsum("ij,ij->i", v[:, 0], np.cross(v[:, 1], v[:, 2])).sum() / 6.0)

    def is_watertight(self) -> bool:
        """Every edge used exactly twice, once in each direction."""
        e = np.concatenate([self.faces[:, [0, 1]], self.faces[:, [1, 2]], self.faces[:, [2, 0]]])
        fwd = {tuple(x) for x in e.tolist()}
        if len(fwd) != len(e):
            return False
        return all((b, a) in fwd for a, b in fwd)


@dataclass
class SupportUnit:
    island_id: int
    support: Mesh             # printed as a Cura support mesh
    blocker: Optional[Mesh]   # used as a Cura anti-overhang mesh
    landing_z: float
    tower_top: float          # where the trunk ends and the head starts
    underside_z: float        # lowest point of the overhang it holds up
    lands_on_plate: bool
    notes: List[str] = field(default_factory=list)
    trunk_xy: Tuple[float, float] = (0.0, 0.0)
    trunk_radius: float = 0.0
    branches: int = 0
    coverage: float = 1.0     # share of the overhang within reach of the head
    region: Optional[np.ndarray] = None   # (N, 3) overhang sample points this unit holds up


# --------------------------------------------------------------------------
# Vertical ray casting with an XY bin grid
# --------------------------------------------------------------------------

class VerticalRaycaster:
    """Answers "surface below", "surface above" and "inside the model?" for vertical lines."""

    def __init__(self, tris: np.ndarray, target_cells: int = 160):
        self.tris = tris.astype(np.float64)
        xy = self.tris[:, :, :2]
        a, b, c = xy[:, 0], xy[:, 1], xy[:, 2]
        self.det = (b[:, 0] - a[:, 0]) * (c[:, 1] - a[:, 1]) - (c[:, 0] - a[:, 0]) * (b[:, 1] - a[:, 1])
        ok = np.abs(self.det) > 1e-12          # vertical (edge-on) triangles never hit a vertical ray
        idx = np.nonzero(ok)[0]
        lo, hi = xy.min(axis=1), xy.max(axis=1)
        self.origin = lo.min(axis=0) if len(lo) else np.zeros(2)
        extent = (hi.max(axis=0) - self.origin) if len(hi) else np.ones(2)
        self.cell = max(float(extent.max()) / target_cells, 1e-3)
        lo_c = np.floor((lo - self.origin) / self.cell).astype(int)
        hi_c = np.floor((hi - self.origin) / self.cell).astype(int)
        tmp: Dict[Tuple[int, int], List[int]] = {}
        for t in idx:
            for i in range(lo_c[t, 0], hi_c[t, 0] + 1):
                for j in range(lo_c[t, 1], hi_c[t, 1] + 1):
                    tmp.setdefault((i, j), []).append(t)
        self.bins = {k: np.asarray(v) for k, v in tmp.items()}

    def hits(self, x: float, y: float) -> Tuple[np.ndarray, np.ndarray]:
        """All crossings of the vertical line through (x, y): heights and up-facing flags."""
        key = (int(math.floor((x - self.origin[0]) / self.cell)),
               int(math.floor((y - self.origin[1]) / self.cell)))
        cand = self.bins.get(key)
        if cand is None:
            return np.zeros(0), np.zeros(0, dtype=bool)
        t = self.tris[cand]
        a, b, c = t[:, 0], t[:, 1], t[:, 2]
        det = self.det[cand]
        l1 = ((b[:, 1] - c[:, 1]) * (x - c[:, 0]) + (c[:, 0] - b[:, 0]) * (y - c[:, 1])) / det
        l2 = ((c[:, 1] - a[:, 1]) * (x - c[:, 0]) + (a[:, 0] - c[:, 0]) * (y - c[:, 1])) / det
        l3 = 1.0 - l1 - l2
        eps = -1e-9
        inside = (l1 >= eps) & (l2 >= eps) & (l3 >= eps)
        z = l1 * a[:, 2] + l2 * b[:, 2] + l3 * c[:, 2]
        return z[inside], det[inside] > 0

    def below(self, x: float, y: float, z: float, eps: float = 1e-3) -> Optional[float]:
        zh, _ = self.hits(x, y)
        zh = zh[zh < z - eps]
        return float(zh.max()) if len(zh) else None

    def below_hit(self, x: float, y: float, z: float, eps: float = 1e-3):
        """(height, up_facing) of the first surface below, or (None, None)."""
        zh, up = self.hits(x, y)
        m = zh < z - eps
        if not m.any():
            return None, None
        k = np.argmax(np.where(m, zh, -np.inf))
        return float(zh[k]), bool(up[k])

    def above(self, x: float, y: float, z: float, eps: float = 1e-3) -> Optional[float]:
        zh, _ = self.hits(x, y)
        zh = zh[zh > z + eps]
        return float(zh.min()) if len(zh) else None

    def inside_many(self, x: float, y: float, zs) -> np.ndarray:
        """Winding test along +Z: works for closed meshes, including overlapping shells."""
        zh, up = self.hits(x + 1.37e-4, y + 0.71e-4)        # nudge off shared edges
        zs = np.atleast_1d(np.asarray(zs, float))
        if not len(zh):
            return np.zeros(len(zs), dtype=bool)
        sign = np.where(up, 1, -1)
        w = (sign[None, :] * (zh[None, :] > zs[:, None])).sum(axis=1)
        return w > 0

    def inside(self, x: float, y: float, z: float) -> bool:
        return bool(self.inside_many(x, y, [z])[0])


# --------------------------------------------------------------------------
# Small geometry helpers
# --------------------------------------------------------------------------

def convex_hull_2d(points: np.ndarray) -> np.ndarray:
    """Monotone chain; returns counter-clockwise hull without repeated end point."""
    pts = np.unique(np.round(points, 6), axis=0)
    if len(pts) < 3:
        return pts
    pts = pts[np.lexsort((pts[:, 1], pts[:, 0]))]

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

    lower, upper = [], []
    for p in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    for p in pts[::-1]:
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    return np.array(lower[:-1] + upper[:-1])


def polygon_area_centroid(poly: np.ndarray) -> Tuple[float, np.ndarray]:
    x, y = poly[:, 0], poly[:, 1]
    xn, yn = np.roll(x, -1), np.roll(y, -1)
    cr = x * yn - xn * y
    area = cr.sum() / 2.0
    if abs(area) < 1e-12:
        return 0.0, poly.mean(axis=0)
    cx = ((x + xn) * cr).sum() / (6 * area)
    cy = ((y + yn) * cr).sum() / (6 * area)
    return abs(area), np.array([cx, cy])


def offset_convex(poly: np.ndarray, d: float) -> np.ndarray:
    """Push a CCW convex polygon outwards by d (mitre joins)."""
    n = len(poly)
    out = []
    for i in range(n):
        p0, p1, p2 = poly[i - 1], poly[i], poly[(i + 1) % n]
        e1, e2 = p1 - p0, p2 - p1
        n1 = np.array([e1[1], -e1[0]]) / (np.linalg.norm(e1) + 1e-12)
        n2 = np.array([e2[1], -e2[0]]) / (np.linalg.norm(e2) + 1e-12)
        bis = n1 + n2
        nb = np.linalg.norm(bis)
        if nb < 1e-9:
            out.append(p1 + n1 * d)
            continue
        bis /= nb
        cosh = max(float(np.dot(bis, n1)), 0.25)  # limit mitre spikes
        out.append(p1 + bis * d / cosh)
    return np.array(out)


def radial_profile(poly: np.ndarray, centre: np.ndarray, angles: np.ndarray) -> np.ndarray:
    """Distance from centre to a convex polygon's edge along each angle."""
    res = np.zeros(len(angles))
    n = len(poly)
    for k, th in enumerate(angles):
        d = np.array([math.cos(th), math.sin(th)])
        best = 0.0
        for i in range(n):
            a, b = poly[i] - centre, poly[(i + 1) % n] - centre
            e = b - a
            den = d[0] * e[1] - d[1] * e[0]
            if abs(den) < 1e-12:
                continue
            t = (a[0] * e[1] - a[1] * e[0]) / den
            s = (a[0] * d[1] - a[1] * d[0]) / den
            if t > 0 and -1e-9 <= s <= 1 + 1e-9:
                best = max(best, t)
        res[k] = best
    return res


def prism(poly: np.ndarray, z0: float, z1: float) -> Mesh:
    """Closed extrusion of a CCW polygon between z0 and z1."""
    n = len(poly)
    v = np.vstack([np.column_stack([poly, np.full(n, z0)]),
                   np.column_stack([poly, np.full(n, z1)]),
                   [[*poly.mean(axis=0), z0]], [[*poly.mean(axis=0), z1]]])
    cb, ct = 2 * n, 2 * n + 1
    f = []
    for i in range(n):
        j = (i + 1) % n
        f += [[i, j, n + j], [i, n + j, n + i]]   # side
        f += [[cb, j, i]]                         # bottom (faces down)
        f += [[ct, n + i, n + j]]                 # top (faces up)
    return Mesh(v, np.array(f))


def tube(cx: float, cy: float, r_out: float, r_in: float, z0: float, z1: float, seg: int) -> Mesh:
    """Closed hollow cylinder (annulus extruded)."""
    th = np.linspace(0, 2 * np.pi, seg, endpoint=False)
    c, s = np.cos(th), np.sin(th)
    rings = []
    for r, z in ((r_out, z0), (r_out, z1), (r_in, z0), (r_in, z1)):
        rings.append(np.column_stack([cx + r * c, cy + r * s, np.full(seg, z)]))
    v = np.vstack(rings)
    ob, ot, ib, it = 0, seg, 2 * seg, 3 * seg
    f = []
    for i in range(seg):
        j = (i + 1) % seg
        f += [[ob + i, ob + j, ot + j], [ob + i, ot + j, ot + i]]   # outer wall
        f += [[ib + i, it + j, ib + j], [ib + i, it + i, it + j]]   # inner wall (faces in)
        f += [[ot + i, ot + j, it + j], [ot + i, it + j, it + i]]   # top ring
        f += [[ob + i, ib + j, ob + j], [ob + i, ib + i, ib + j]]   # bottom ring
    return Mesh(v, np.array(f))


def gusset(cx: float, cy: float, angle: float, r_start: float, length: float,
           height: float, thickness: float, z0: float) -> Mesh:
    """Triangular fin standing on z0, leaning on the tower wall."""
    d = np.array([math.cos(angle), math.sin(angle)])
    nrm = np.array([-d[1], d[0]]) * thickness / 2
    base = np.array([cx, cy]) + d * r_start
    p_in_bot = base
    p_out_bot = base + d * length
    p_in_top = base
    profile = [(p_in_bot, z0), (p_out_bot, z0), (p_in_top, z0 + height)]
    v = []
    for side in (-1, 1):
        for p, z in profile:
            q = p + side * nrm
            v.append([q[0], q[1], z])
    v = np.array(v)
    # 0,1,2 = side -1 ; 3,4,5 = side +1
    f = [[0, 2, 1], [3, 4, 5],                 # triangle faces
         [0, 1, 4], [0, 4, 3],                 # bottom
         [1, 2, 5], [1, 5, 4],                 # slope
         [2, 0, 3], [2, 3, 5]]                 # inner (against tube)
    m = Mesh(v, np.array(f))
    if m.volume() < 0:
        m.faces = m.faces[:, ::-1]
    return m


def loft(p, angles, sections) -> Mesh:
    """Sweep a cross-section around a vertical axis at p.

    sections: (K, M, 2) array of (radius, z) per angle, the same M-gon for every angle,
    listed counter-clockwise in the (r, z) plane. The result is a closed ring-shaped solid.
    """
    sec = np.asarray(sections, float)
    k_, m_ = sec.shape[0], sec.shape[1]
    v = np.empty((k_ * m_, 3))
    for k, a in enumerate(angles):
        d = np.array([math.cos(a), math.sin(a)])
        v[k * m_:(k + 1) * m_, :2] = p + sec[k, :, :1] * d
        v[k * m_:(k + 1) * m_, 2] = sec[k, :, 1]
    f = []
    for k in range(k_):
        k2 = (k + 1) % k_
        for i in range(m_):
            i2 = (i + 1) % m_
            a, b = k * m_ + i, k * m_ + i2
            c, d_ = k2 * m_ + i2, k2 * m_ + i
            f += [[a, b, c], [a, c, d_]]
    m = Mesh(v, np.array(f))
    if m.volume() < 0:
        m.faces = m.faces[:, ::-1]
    return m


def fin(p, u, ss, zb, zt, thickness: float) -> Mesh:
    """A vertical wedge-shaped web from p along unit vector u.

    ss: distances along u; zb/zt: bottom and top height at each distance.
    """
    n = np.array([-u[1], u[0]]) * thickness / 2
    v = []
    for s_, b_, t_ in zip(ss, zb, zt):
        c = p + u * s_
        for side in (n, -n):
            q = c + side
            v.append([q[0], q[1], b_])
            v.append([q[0], q[1], t_])
    v = np.array(v)
    k_ = len(ss)
    f = []
    for k in range(k_ - 1):
        lb, lt, rb, rt = 4 * k, 4 * k + 1, 4 * k + 2, 4 * k + 3
        lb2, lt2, rb2, rt2 = lb + 4, lt + 4, rb + 4, rt + 4
        f += [[lb, lb2, lt2], [lb, lt2, lt]]          # left face
        f += [[rb, rt2, rb2], [rb, rt, rt2]]          # right face
        f += [[lt, lt2, rt2], [lt, rt2, rt]]          # top
        f += [[lb, rb2, lb2], [lb, rb, rb2]]          # bottom
    e = 4 * (k_ - 1)
    f += [[0, 1, 3], [0, 3, 2]]                       # start cap
    f += [[e, e + 2, e + 3], [e, e + 3, e + 1]]       # end cap
    m = Mesh(v, np.array(f))
    if m.volume() < 0:
        m.faces = m.faces[:, ::-1]
    return m


# --------------------------------------------------------------------------
# Overhang sampling and support regions
# --------------------------------------------------------------------------

def overhang_triangles(tris: np.ndarray, s: HybridSettings) -> np.ndarray:
    e1 = tris[:, 1] - tris[:, 0]
    e2 = tris[:, 2] - tris[:, 0]
    n = np.cross(e1, e2)
    area2 = np.linalg.norm(n, axis=1)
    with np.errstate(invalid="ignore", divide="ignore"):
        nz = np.where(area2 > 0, n[:, 2] / area2, 0.0)
    over = (-nz > math.cos(math.radians(s.support_angle))) & (tris[:, :, 2].min(axis=1) > s.bed_tolerance)
    return tris[over]


def _subdivide(tris: np.ndarray, max_edge: float, limit: int = 600000) -> np.ndarray:
    """Split triangles along their longest edge until every edge is <= max_edge."""
    done, todo = [], tris
    total = 0
    while len(todo):
        e = np.stack([np.linalg.norm(todo[:, 1] - todo[:, 0], axis=1),
                      np.linalg.norm(todo[:, 2] - todo[:, 1], axis=1),
                      np.linalg.norm(todo[:, 0] - todo[:, 2], axis=1)], axis=1)
        long_ = e.max(axis=1) > max_edge
        done.append(todo[~long_])
        total += int((~long_).sum())
        t = todo[long_]
        if total + 2 * len(t) > limit:
            done.append(t)
            break
        k = np.argmax(e[long_], axis=1)
        r = np.arange(len(t))
        a, b, c = t[r, k], t[r, (k + 1) % 3], t[r, (k + 2) % 3]
        m = (a + b) / 2
        todo = np.concatenate([np.stack([a, m, c], 1), np.stack([m, b, c], 1)])
    return np.concatenate(done) if done else tris[:0]


def island_xy_area(t: np.ndarray) -> float:
    a = t[:, 1, :2] - t[:, 0, :2]
    b = t[:, 2, :2] - t[:, 0, :2]
    return float(0.5 * np.abs(a[:, 0] * b[:, 1] - a[:, 1] * b[:, 0]).sum())


@dataclass
class Region:
    pts: np.ndarray       # (N, 3) x, y, underside z
    land: np.ndarray      # (N,) surface below each point
    cell: float


def find_regions(tris: np.ndarray, rc: VerticalRaycaster, s: HybridSettings) -> List[Region]:
    over = overhang_triangles(tris, s)
    if not len(over):
        return []
    xy = over[:, :, :2].reshape(-1, 2)
    ext = xy.max(axis=0) - xy.min(axis=0)
    area = island_xy_area(over)
    c = float(np.clip(math.sqrt(max(area, 1.0) / 40000.0), 0.6, 2.0))
    pieces = _subdivide(over, c * 0.7)
    cen = pieces.mean(axis=1)
    origin = xy.min(axis=0) - c
    ij = np.floor((cen[:, :2] - origin) / c).astype(np.int64)
    order = np.lexsort((cen[:, 2], ij[:, 1], ij[:, 0]))
    ij, cen = ij[order], cen[order]

    # nodes: per grid cell, one node per separate height
    nodes_xy, nodes_z, nodes_ij = [], [], []
    start = 0
    n = len(cen)
    z_split = c + 1.0
    while start < n:
        end = start + 1
        while end < n and ij[end, 0] == ij[start, 0] and ij[end, 1] == ij[start, 1]:
            end += 1
        g0 = start
        for k in range(start + 1, end + 1):
            if k == end or cen[k, 2] - cen[k - 1, 2] > z_split:
                grp = cen[g0:k]
                nodes_xy.append(grp[:, :2].mean(axis=0))
                nodes_z.append(grp[:, 2].min())
                nodes_ij.append(ij[start])
                g0 = k
        start = end
    nodes_xy = np.array(nodes_xy)
    nodes_z = np.array(nodes_z)
    nodes_ij = np.array(nodes_ij)

    # keep nodes with open space below them, record where they would stand
    min_gap = max(3 * s.layer_height, 0.8)
    keep, land = [], []
    for k in range(len(nodes_z)):
        x, y, z = nodes_xy[k, 0], nodes_xy[k, 1], nodes_z[k]
        hz, up = rc.below_hit(x, y, z - 0.01)
        if hz is not None and not up:          # the space under this face is inside the model
            continue
        lz = hz if hz is not None else 0.0
        if lz <= s.bed_tolerance:
            lz = 0.0
        if z - lz < min_gap or rc.inside(x, y, z - 0.05):
            continue
        keep.append(k)
        land.append(lz)
    if not keep:
        return []
    keep = np.array(keep)
    pts = np.column_stack([nodes_xy[keep], nodes_z[keep]])
    land = np.array(land)
    cij = nodes_ij[keep]

    # connect neighbouring nodes at a similar height
    parent = list(range(len(pts)))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    cells: Dict[Tuple[int, int], List[int]] = {}
    for k, (i, j) in enumerate(cij.tolist()):
        cells.setdefault((i, j), []).append(k)
    dz_link = 1.2 * c + 0.4
    for (i, j), ks in cells.items():
        for di in (0, 1):
            for dj in (-1, 0, 1):
                if di == 0 and dj <= 0:
                    continue
                other = cells.get((i + di, j + dj))
                if not other:
                    continue
                for a in ks:
                    for b in other:
                        if abs(pts[a, 2] - pts[b, 2]) <= dz_link:
                            ra, rb = find(a), find(b)
                            if ra != rb:
                                parent[ra] = rb
    groups: Dict[int, List[int]] = {}
    for k in range(len(pts)):
        groups.setdefault(find(k), []).append(k)
    out = []
    for g in groups.values():
        g = np.array(g)
        if len(g) * c * c >= s.min_island_area:
            out.append(Region(pts[g], land[g], c))
    return out


def split_region(r: Region) -> List[Region]:
    """Cut a region in two across its longest direction."""
    xy = r.pts[:, :2] - r.pts[:, :2].mean(axis=0)
    if len(xy) < 4:
        return [r]
    _, _, vt = np.linalg.svd(xy, full_matrices=False)
    proj = xy @ vt[0]
    m = proj <= np.median(proj)
    if m.all() or (~m).all():
        return [r]
    return [Region(r.pts[m], r.land[m], r.cell), Region(r.pts[~m], r.land[~m], r.cell)]


# --------------------------------------------------------------------------
# One support unit: trunk + head
# --------------------------------------------------------------------------

class _TopLookup:
    """Underside height (minus the contact gap) near an XY point, from the region samples."""

    def __init__(self, r: Region, gap: float):
        self.c = r.cell
        self.o = r.pts[:, :2].min(axis=0) - 2 * r.cell
        self.d: Dict[Tuple[int, int], float] = {}
        for x, y, z in r.pts:
            key = (int((x - self.o[0]) // self.c), int((y - self.o[1]) // self.c))
            self.d[key] = min(self.d.get(key, 1e9), z - gap)

    def __call__(self, x: float, y: float) -> Optional[float]:
        i, j = int((x - self.o[0]) // self.c), int((y - self.o[1]) // self.c)
        best = None
        for di in (-1, 0, 1):
            for dj in (-1, 0, 1):
                v = self.d.get((i + di, j + dj))
                if v is not None and (best is None or v < best):
                    best = v
        return best


def _place_trunk(r: Region, rc: VerticalRaycaster, s: HybridSettings, tan_f: float, tip_h: float):
    """Best trunk position: clear column, lowest reach. Returns a dict or None, plus the best miss."""
    xy, z = r.pts[:, :2], r.pts[:, 2]
    cen = xy.mean(axis=0)
    step = max(1, len(xy) // 60)
    cands = [cen[None], xy[::step]]
    hull = convex_hull_2d(xy)
    if len(hull) >= 3:                     # also just outside the overhang (e.g. a rib on a wall)
        mids = (hull + np.roll(hull, -1, axis=0)) / 2
        for off in (s.min_tower_radius + s.xy_clearance + 0.3,
                    0.5 * (s.min_tower_radius + s.max_tower_radius) + s.xy_clearance,
                    s.max_tower_radius + s.xy_clearance):
            cands += [offset_convex(hull, off), offset_convex(mids if len(mids) >= 3 else hull, off)]
    cands = np.vstack(cands)
    dist = np.linalg.norm(xy[None, :, :] - cands[:, None, :], axis=2)
    reach = dist.max(axis=1)
    zmin = float(z.min())
    gap = s.contact_gap
    best_miss = None
    ring = np.linspace(0, 2 * np.pi, 16, endpoint=False)
    tried = 0
    for k in np.argsort(reach):
        p = cands[k]
        rt = float(np.clip(s.tower_scale * reach[k], s.min_tower_radius, s.max_tower_radius))
        rt = max(rt, (s.wall_lines + 1) * s.line_width)
        probe = zmin - 0.02
        pts = [p] + [p + (rt + s.xy_clearance) * np.array([math.cos(a), math.sin(a)]) for a in ring]
        lands = []
        bad = False
        for q in pts:
            hz, up = rc.below_hit(q[0], q[1], probe)
            if hz is not None and not up:      # inside the model here
                bad = True
                break
            lands.append(hz if hz is not None else 0.0)
        tried += 1
        if not bad:
            bad = not _sees(rc, p, xy, zmin - gap - 0.3, s.xy_clearance)
        if not bad and max(lands) - min(lands) <= 1.0:
            z_land = max(lands)
            if z_land <= s.bed_tolerance:
                z_land = 0.0
            need = z - gap - tip_h - np.maximum(0.0, dist[k] - rt) / tan_f
            z_h0 = float(need.min())
            if z_h0 >= z_land:
                return {"p": p, "rt": rt, "z_land": z_land, "z_h0": z_h0, "dist": dist[k]}, None
            miss = {"p": p, "rt": rt, "z_land": z_land, "need": need, "dist": dist[k]}
            if best_miss is None or z_h0 - z_land > best_miss["score"]:
                miss["score"] = z_h0 - z_land
                best_miss = miss
        if tried >= 40:
            break
    return None, best_miss


def _sees(rc: VerticalRaycaster, p, xy, z: float, clear: float) -> bool:
    """Is there a clear straight path at height z from p to the nearest overhang point?"""
    d = np.linalg.norm(xy - p, axis=1)
    q = xy[d.argmin()]
    L = float(d.min())
    if L < 1e-6:
        return not rc.inside(p[0], p[1], z)
    u = (q - p) / L
    for t in np.arange(0.0, L + 1e-9, 0.5):
        a = p + u * t
        if rc.inside(a[0], a[1], z):
            return False
    return True


def _clear(rc: VerticalRaycaster, x: float, y: float, zs, u, half: float, side_zs=None) -> bool:
    """True when the points (x, y, zs) and their sideways neighbours are outside the model.

    The sideways test uses side_zs (default: zs) so a sloped or curved underside right above
    the branch top does not count as a collision.
    """
    if rc.inside_many(x, y, zs).any():
        return False
    n = np.array([-u[1], u[0]])
    for off in (half, -half):
        q = np.array([x, y]) + n * off
        if rc.inside_many(q[0], q[1], zs if side_zs is None else side_zs).any():
            return False
    return True


def _build_fin(p, u, length, rt, z_h0, top: _TopLookup, rc: VerticalRaycaster, s: HybridSettings,
               tan_f: float, tip_h: float, thick: float, standing: bool = False):
    """Profile of one branch towards direction u; shortened where it would hit the model."""
    step = max(0.5, top.c / 2)
    ss = np.unique(np.append(np.arange(0.0, length, step), length))
    zt = []
    nrm = np.array([-u[1], u[0]]) * (thick / 2)
    for s_ in ss:
        q = p + u * s_
        vals = [v for v in (top(q[0], q[1]), top(*(q + nrm)), top(*(q - nrm))) if v is not None]
        zt.append(min(vals) if vals else np.nan)     # both faces of the web stay under the model
    zt = np.array(zt)
    if np.isnan(zt).all():
        return None
    good = ~np.isnan(zt)
    zt = np.interp(ss, ss[good], zt[good])
    for k, s_ in enumerate(ss):      # exact check: the model surface right above each face of the web
        q = p + u * s_
        for o in (q, q + nrm, q - nrm):
            a = rc.above(o[0], o[1], min(zt[k], z_h0 if not standing else zt[k]) - 0.5)
            if a is not None and a - s.contact_gap < zt[k]:
                zt[k] = a - s.contact_gap
    if standing:                     # a web standing on whatever is below it
        zb = []
        for s_, t_ in zip(ss, zt):
            q = p + u * s_
            g = rc.below(q[0], q[1], t_)
            zb.append(0.0 if g is None or g <= s.bed_tolerance else g)
        zb = np.array(zb)
        tip_h = 0.4
    else:
        zb = z_h0 + np.maximum(0.0, ss - rt) / tan_f
    half = thick / 2 + s.xy_clearance
    keep = len(ss)
    for k, s_ in enumerate(ss):
        if zt[k] - zb[k] < tip_h * 0.5:
            keep = k
            break
        q = p + u * s_
        zs = [zb[k] + 0.05, (zb[k] + zt[k]) / 2, zt[k] - 0.05]
        side = [zb[k] + 0.05, (zb[k] + zt[k]) / 2]
        if not _clear(rc, q[0], q[1], zs, u, half if s_ > rt else thick / 2, side):
            keep = k
            break
    if keep < len(ss):
        # back off by the clearance so Cura's X/Y distance does not eat the tip
        cut = ss[keep] - s.xy_clearance - step
        m = ss <= cut
        if m.sum() < 2:
            return None
        ss, zb, zt = ss[m], zb[m], zt[m]
    if ss[-1] <= rt * 0.5 and not standing:
        return None
    if standing and ss[-1] < 0.5:
        return None
    zt = np.maximum(zt, zb + 0.2)
    return ss, zb, zt


def _gussets(p, rt, wall, z_land, trunk_h, rc: VerticalRaycaster, s: HybridSettings, notes) -> List[Mesh]:
    if s.gusset_count <= 0 or s.gusset_height <= 0 or s.gusset_length <= 0 or trunk_h < 2.0:
        return []
    g_h = min(s.gusset_height, 0.5 * trunk_h)
    if g_h < s.gusset_height:
        notes.append(f"gusset height capped to {g_h:.1f} mm")
    thick = max(1, s.wall_lines) * s.line_width
    out, trimmed = [], 0
    for k in range(s.gusset_count):
        a = 2 * np.pi * k / s.gusset_count + np.pi / 4
        u = np.array([math.cos(a), math.sin(a)])
        r0 = rt - 0.5 * wall
        length = s.gusset_length + 0.5 * wall
        ok_len = 0.0
        for d in np.unique(np.append(np.arange(0.5, length, 0.5), length)):
            q = p + u * (r0 + d)
            h = g_h * (1 - d / length)
            zs = [z_land + 0.05, z_land + max(0.1, h - 0.05)]
            if not _clear(rc, q[0], q[1], zs, u, thick / 2 + s.xy_clearance):
                break
            if z_land > 0:          # standing on the model: the foot needs ground under it
                below = rc.below(q[0], q[1], z_land + 0.3)
                if below is None or below < z_land - 0.3:
                    break
            ok_len = d
        if ok_len < length - 1e-6:
            trimmed += 1
            ok_len = max(0.0, ok_len - s.xy_clearance)
        if ok_len < 1.0:
            continue
        h_eff = g_h * ok_len / length if ok_len < length else g_h
        out.append(gusset(p[0], p[1], a, r0, ok_len, max(h_eff, 0.5), thick, z_land))
    if trimmed:
        notes.append(f"{trimmed} gusset(s) shortened to keep clear of the model")
    return out


def _branches(p, rt, z_h0, pts, top, rc, s, tan_f, tip_h, thick, standing, covered=None, limit=None):
    """Greedy fan of fins until every overhang point is near one. Returns meshes and the covered mask."""
    d = np.linalg.norm(pts[:, :2] - p, axis=1)
    cover = s.bridge_gap / 2
    covered = (np.zeros(len(pts), dtype=bool) if covered is None else covered.copy()) | (d <= rt)
    dead = np.zeros(len(pts), dtype=bool)
    meshes = []
    limit = s.max_branches if limit is None else limit
    while not (covered | dead).all() and len(meshes) < limit:
        far = np.where(covered | dead, -1, d).argmax()
        if d[far] < 1e-6:
            covered[far] = True
            continue
        u = (pts[far, :2] - p) / d[far]
        prof = _build_fin(p, u, d[far], rt, z_h0, top, rc, s, tan_f, tip_h, thick, standing)
        if prof is None:
            dead[far] = True
            continue
        ss, zb, zt = prof
        meshes.append(fin(p, u, ss, zb, zt, thick))
        seg = u * ss[-1]
        t = np.clip(((pts[:, :2] - p) @ seg) / max(seg @ seg, 1e-9), 0, 1)
        near = np.linalg.norm(pts[:, :2] - (p + t[:, None] * seg), axis=1)
        covered |= near <= cover
        if ss[-1] < d[far] - 1e-6:
            dead[far] = True
    return meshes, covered


def _cone_head(p, rt, wall, z_h0, pts, top: _TopLookup, rc: VerticalRaycaster, s: HybridSettings, tan_f: float):
    """Hollow inverted cone from the trunk top, plus thin vertical rings standing on its inside.

    Per direction the cone wall rises at the flare angle until it reaches the edge of the
    overhang (or the model, or the underside), then goes straight up to the underside.
    Returns (meshes, covered mask).
    """
    K = max(24, 2 * s.segments)
    angles = np.linspace(0, 2 * np.pi, K, endpoint=False)
    rel = pts[:, :2] - p
    rho = np.linalg.norm(rel, axis=1)
    phi = np.mod(np.arctan2(rel[:, 1], rel[:, 0]), 2 * np.pi)
    bins = np.round(phi / (2 * np.pi / K)).astype(int) % K
    reach = np.full(K, rt)
    for k in range(K):                       # far edge of the overhang in each direction (+ neighbours)
        m = (bins == k) | (bins == (k + 1) % K) | (bins == (k - 1) % K)
        if m.any():
            reach[k] = max(rt, float(rho[m].max()) + top.c / 2)

    def ceiling(x, y, z_from):
        v = top(x, y)
        a = rc.above(x, y, z_from)
        if a is not None:
            v = a - s.contact_gap if v is None else min(v, a - s.contact_gap)
        return v

    step = 0.5
    r1 = np.full(K, rt)
    z1 = np.full(K, z_h0)
    zt1 = np.full(K, z_h0)
    for k, a in enumerate(angles):
        d = np.array([math.cos(a), math.sin(a)])
        r = rt
        while r < reach[k] - 1e-9:
            rn = min(r + step, reach[k])
            zc = z_h0 + (rn - rt) / tan_f
            q = p + d * rn
            cz = ceiling(q[0], q[1], zc - 1.0)
            if cz is not None and zc >= cz:        # the cone meets the underside
                break
            qq = p + d * (rn + s.xy_clearance)
            if rc.inside_many(q[0], q[1], [zc, zc + 0.3]).any() or rc.inside(qq[0], qq[1], zc):
                rn = max(rt, r - s.xy_clearance)    # keep clear of the model
                r = rn
                break
            r = rn
        r1[k] = r
        z1[k] = z_h0 + (r - rt) / tan_f
    w = wall

    def tops(radii, z_from):
        """Underside height over both faces of a wall at these radii, smoothed over neighbours."""
        raw = np.full(K, np.inf)
        for k, a in enumerate(angles):
            d = np.array([math.cos(a), math.sin(a)])
            for rr in (radii[k], max(radii[k] - w, 0.0)):
                q = p + d * rr
                cz = ceiling(q[0], q[1], z_from[k])
                if cz is not None:
                    raw[k] = min(raw[k], cz)
        return np.minimum(raw, np.minimum(np.roll(raw, 1), np.roll(raw, -1)))

    t1 = tops(r1, z1)
    zt1 = np.where(np.isfinite(t1) & (r1 > rt + 1e-6), np.maximum(z1, t1), z1)
    sec = []
    for k in range(K):
        sec.append([(rt, z_h0), (r1[k], z1[k]), (r1[k], zt1[k]),
                    (r1[k] - w, zt1[k]), (r1[k] - w, z1[k]), (rt - w, z_h0)])
    meshes = [loft(p, angles, np.array(sec))]

    gap = s.bridge_gap
    fill = s.cone_fill if gap > 0 else "none"
    cell = top.c
    rim_d = np.maximum(r1[bins] - rho, 0.0)          # distance from each point out to the cone rim
    if fill == "rings":
        radii = [r1.copy()]
        n = 1
        while True:
            rk = r1 - n * gap
            if rk.max() < rt + 0.5 * gap or n > 40:
                break
            rk = np.maximum(rk, rt + w)
            zb = z_h0 + (rk - rt) / tan_f
            tk = tops(rk, zb + 0.05)
            zt = np.where(np.isfinite(tk), tk, zb)
            zt = np.maximum(zt, zb + 0.2)
            ring = [[(rk[k], zb[k] - 0.05), (rk[k], zt[k]), (rk[k] - w, zt[k]), (rk[k] - w, zb[k] - 0.05)]
                    for k in range(K)]
            meshes.append(loft(p, angles, np.array(ring)))
            radii.append(rk)
            n += 1
        dist = np.min([np.abs(rho - rk[bins]) for rk in radii], axis=0)
        covered = (rho <= rt) | ((2 * dist <= gap + cell) & (rho <= r1[bins] + cell))
    elif fill == "cross":
        # spokes from the trunk to the corners of the overhang, then wherever the longest bridge is
        thick = max(w, s.min_branch_thickness)
        hull = convex_hull_2d(pts[:, :2])
        dirs = []
        if len(hull) >= 3:
            for i in range(len(hull)):
                a_, b_, c_ = hull[i - 1], hull[i], hull[(i + 1) % len(hull)]
                v1, v2 = a_ - b_, c_ - b_
                cosang = float(v1 @ v2 / (np.linalg.norm(v1) * np.linalg.norm(v2) + 1e-12))
                if cosang > math.cos(math.radians(150)):      # a real corner
                    dirs.append(math.atan2(b_[1] - p[1], b_[0] - p[0]))
        if len(dirs) < 2:
            dirs = [k * np.pi / 2 for k in range(4)]
        spoke_len = {}

        def add_spoke(a):
            k = int(round(np.mod(a, 2 * np.pi) / (2 * np.pi / K))) % K
            if r1[k] <= rt + 0.5:
                return None
            u = np.array([math.cos(a), math.sin(a)])
            prof = _build_fin(p, u, r1[k], rt, z_h0, top, rc, s, tan_f, 0.5, thick)
            if prof is None:
                return None
            ss, zb, zt = prof
            meshes.append(fin(p, u, ss, zb, zt, thick))
            return u * ss[-1]

        segs = []
        for a in dirs:
            sg = add_spoke(a)
            if sg is not None:
                segs.append(sg)
        tried = set()
        while len(segs) < 16:
            if segs:
                d_sp = np.min([np.linalg.norm(rel - np.clip((rel @ sg) / (sg @ sg), 0, 1)[:, None] * sg, axis=1)
                               for sg in segs], axis=0)
            else:
                d_sp = np.full(len(pts), np.inf)
            span = 2 * np.minimum(d_sp, rim_d)
            span[rho <= rt] = 0
            worst = int(span.argmax())
            if span[worst] <= gap + cell or round(phi[worst], 2) in tried:
                break
            tried.add(round(phi[worst], 2))
            sg = add_spoke(phi[worst])
            if sg is not None:
                segs.append(sg)
        if segs:
            d_sp = np.min([np.linalg.norm(rel - np.clip((rel @ sg) / (sg @ sg), 0, 1)[:, None] * sg, axis=1)
                           for sg in segs], axis=0)
        else:
            d_sp = np.full(len(pts), np.inf)
        covered = (rho <= rt) | ((2 * np.minimum(d_sp, rim_d) <= gap + cell) & (rho <= r1[bins] + cell))
    else:
        covered = (rho <= rt) | (rho <= r1[bins] + cell)
    return meshes, covered


def _reachable(pts, rc: VerticalRaycaster, clear: float) -> np.ndarray:
    """Points Cura would let support reach: not within the X/Y distance of the model sideways."""
    ok = np.ones(len(pts), dtype=bool)
    for k, (x, y, z) in enumerate(pts):
        for dx, dy in ((clear, 0), (-clear, 0), (0, clear), (0, -clear)):
            if rc.inside(x + dx, y + dy, z - 0.3):
                ok[k] = False
                break
    return ok


def _blocker(pts, s):
    if not s.blocker:
        return None
    hull = convex_hull_2d(pts[:, :2])
    if len(hull) < 3:
        return None
    z_lo = max(float(pts[:, 2].min()) - 0.5, 0.0)
    z_hi = float(pts[:, 2].max()) + 0.5
    return prism(offset_convex(hull, s.blocker_margin), z_lo, z_hi)


def _low_unit(r: Region, rc: VerticalRaycaster, s: HybridSettings, uid: int, notes) -> List[SupportUnit]:
    """Low overhangs: thin webs standing on the surface below, fanned out from a few points."""
    pts = r.pts
    thick = max(s.branch_lines * s.line_width, s.min_branch_thickness)
    top = _TopLookup(r, s.contact_gap)
    covered = np.zeros(len(pts), dtype=bool)
    tried = np.zeros(len(pts), dtype=bool)
    meshes, hubs = [], []
    if s.bridge_gap <= 0:
        s = HybridSettings(**{**s.__dict__, "bridge_gap": 10.0})
    while len(hubs) < 8 and len(meshes) < s.max_branches and not (covered | tried).all():
        open_ = ~(covered | tried)
        cen = pts[open_, :2].mean(axis=0)
        order = np.where(open_)[0][np.argsort(np.linalg.norm(pts[open_, :2] - cen, axis=1))]
        p = None
        for k in order[:30]:
            tried[k] = True
            q = pts[k]
            if not rc.inside(q[0], q[1], (q[2] + r.land[k]) / 2):
                p = q[:2]
                break
        if p is None:
            continue
        new, covered = _branches(p, 0.0, 0.0, pts, top, rc, s, 1.0, 0.4, thick, True, covered,
                                 limit=s.max_branches - len(meshes))
        if new:
            meshes += new
            hubs.append(p)
    if not meshes:
        return []
    coverage = float((covered | ~_reachable(pts, rc, s.xy_clearance)).mean())
    notes.append("low overhang: standing webs")
    if coverage < 0.98:
        notes.append(f"webs reach {100 * coverage:.0f}% of this overhang")
    land = float(r.land.min())
    p = hubs[0]
    return [SupportUnit(uid, Mesh.concat(meshes), _blocker(pts, s), land, land, float(pts[:, 2].min()),
                        land == 0.0, notes, (float(p[0]), float(p[1])), 0.0, len(meshes), coverage, pts)]


def build_unit(r: Region, rc: VerticalRaycaster, s: HybridSettings, uid: int, depth: int = 0) -> List[SupportUnit]:
    tan_f = math.tan(math.radians(s.max_flare_angle))
    tip_h = 1.5
    notes: List[str] = []
    pts = r.pts
    span = float(np.ptp(pts[:, :2], axis=0).max()) if len(pts) > 1 else 0.0
    if span > s.max_span and depth < 6:
        return [u for part in split_region(r) for u in build_unit(part, rc, s, uid, depth + 1)]
    if float((pts[:, 2] - r.land).max()) <= s.low_gap:
        return _low_unit(r, rc, s, uid, notes)

    place, miss = _place_trunk(r, rc, s, tan_f, tip_h)
    if place is None:
        if depth < 5 and len(pts) >= 8:
            parts = split_region(r)
            if len(parts) > 1:
                return [u for part in parts for u in build_unit(part, rc, s, uid, depth + 1)]
        if s.head_mode == "branch":
            return _low_unit(r, rc, s, uid, notes)
        if miss is None:
            return []
        keep = miss["need"] >= miss["z_land"]
        if keep.sum() < 2:
            return []
        notes.append(f"{100 * (1 - keep.mean()):.0f}% of this overhang is too wide for its height")
        r = Region(pts[keep], r.land[keep], r.cell)
        pts = r.pts
        place = {"p": miss["p"], "rt": miss["rt"], "z_land": miss["z_land"],
                 "z_h0": float(miss["need"][keep].min()), "dist": miss["dist"][keep]}

    p, rt, z_land, z_h0 = place["p"], place["rt"], place["z_land"], place["z_h0"]
    wall = max(1, s.wall_lines) * s.line_width
    top = _TopLookup(r, s.contact_gap)
    parts: List[Mesh] = []
    trunk_h = z_h0 - z_land
    hub_top = top(p[0], p[1])
    if hub_top is None:
        hub_top = float(pts[:, 2].min()) - s.contact_gap
    hub_top = max(hub_top, z_h0 + 0.5)
    has_trunk = trunk_h >= 1.0
    if not has_trunk:
        z_h0 = z_land
    coverage, n_br = 1.0, 0

    if s.head_mode == "cone":
        if has_trunk:
            parts.append(tube(p[0], p[1], rt, rt - wall, z_land, hub_top, s.segments))
        cone_meshes, cov_mask = _cone_head(p, rt, wall, z_h0, pts, top, rc, s, tan_f)
        parts += cone_meshes
        n_br = len(cone_meshes) - 1
        reach_ok = _reachable(pts, rc, s.xy_clearance)
        coverage = float((cov_mask | ~reach_ok).mean())
        if coverage < 0.98:
            notes.append(f"cone reaches {100 * coverage:.0f}% of this overhang")
    elif s.head_mode == "branch":
        thick = max(s.branch_lines * s.line_width, s.min_branch_thickness)
        if has_trunk:
            parts.append(tube(p[0], p[1], rt, rt - wall, z_land, hub_top, s.segments))
        fins, cov_mask = _branches(p, rt, z_h0, pts, top, rc, s, tan_f, tip_h, thick, standing=False)
        coverage = float((cov_mask | ~_reachable(pts, rc, s.xy_clearance)).mean())
        parts += fins
        n_br = len(fins)
        if coverage < 0.98:
            notes.append(f"branches reach {100 * coverage:.0f}% of this overhang")
        if not parts:
            return []
    else:
        hull = convex_hull_2d(pts[:, :2])
        if len(hull) < 3:
            return []
        min_head = s.head_fraction * (float(pts[:, 2].min()) - z_land)
        z_h0 = min(z_h0, float(pts[:, 2].min()) - s.contact_gap - min_head)
        z_h0 = max(z_h0, z_land)
        has_trunk = z_h0 - z_land >= 1.0
        if has_trunk:
            parts.append(tube(p[0], p[1], rt, rt - wall, z_land, z_h0, s.segments))
        zmin_gap = float(pts[:, 2].min()) - s.contact_gap
        z_base = z_h0

        def ray_cap(x, y, v):        # never let the head top poke into the model
            a = rc.above(x, y, z_base + 0.05)
            return v if a is None else min(v, a - s.contact_gap)

        if s.head_mode == "conform":
            def top_fn(x, y):
                v = top(x, y)
                return ray_cap(x, y, zmin_gap if v is None else v)
        else:
            def top_fn(x, y):
                return ray_cap(x, y, zmin_gap)
        parts.append(_head(p, rt, z_h0 - 0.05 if has_trunk else z_h0, hull, top_fn, s))

    if has_trunk:
        parts += _gussets(p, rt, wall, z_land, z_h0 - z_land, rc, s, notes)
    return [SupportUnit(uid, Mesh.concat(parts), _blocker(pts, s), z_land, z_h0 if has_trunk else z_land,
                        float(pts[:, 2].min()), z_land == 0.0, notes, (float(p[0]), float(p[1])), rt,
                        n_br, coverage, pts)]


def generate(vertices: np.ndarray, faces: np.ndarray, s: Optional[HybridSettings] = None) -> List[SupportUnit]:
    """Main entry point. vertices (N,3) Z-up mm, faces (M,3) int."""
    s = s or HybridSettings()
    tris = np.asarray(vertices, dtype=np.float64)[np.asarray(faces)]
    rc = VerticalRaycaster(tris)
    units: List[SupportUnit] = []
    for region in find_regions(tris, rc, s):
        for u in build_unit(region, rc, s, len(units)):
            if len(u.support.faces):
                u.island_id = len(units)
                units.append(u)
    return units


# --------------------------------------------------------------------------
# Solid heads (trapezoid / conform) and debug export
# --------------------------------------------------------------------------

def _head(centre, r_base, z_base, hull, top_z_fn, s: HybridSettings) -> Mesh:
    """Star-shaped closed head: circle at z_base flaring to the hull at the top.

    Top surface is a polar grid; each sample's height comes from top_z_fn.
    """
    seg, rings = s.segments, max(1, s.head_rings)
    ang = np.linspace(0, 2 * np.pi, seg, endpoint=False)
    rad = radial_profile(hull, centre, ang)
    rad = np.maximum(rad, r_base)   # never narrower than the tube
    v = [[centre[0], centre[1], z_base]]                       # 0 bottom centre
    for k in range(seg):                                       # 1..seg bottom circle
        v.append([centre[0] + r_base * math.cos(ang[k]), centre[1] + r_base * math.sin(ang[k]), z_base])
    top_c = len(v)
    v.append([centre[0], centre[1], top_z_fn(centre[0], centre[1])])
    ring_start = len(v)
    for r_i in range(1, rings + 1):                            # top polar grid
        t = r_i / rings
        for k in range(seg):
            x = centre[0] + rad[k] * t * math.cos(ang[k])
            y = centre[1] + rad[k] * t * math.sin(ang[k])
            v.append([x, y, top_z_fn(x, y)])
    v = np.array(v)
    v[top_c + 1:, 2] = np.maximum(v[top_c + 1:, 2], z_base + 0.2)
    v[top_c, 2] = max(v[top_c, 2], z_base + 0.2)

    def ring(r_i, k):
        return ring_start + (r_i - 1) * seg + (k % seg)

    f = []
    for k in range(seg):
        j = (k + 1) % seg
        f.append([0, 1 + j, 1 + k])                           # bottom disc (down)
        f.append([top_c, ring(1, k), ring(1, j)])             # top centre fan (up)
        for r_i in range(1, rings):
            a, b = ring(r_i, k), ring(r_i, j)
            c, d = ring(r_i + 1, k), ring(r_i + 1, j)
            f += [[a, c, d], [a, d, b]]
        o_k, o_j = ring(rings, k), ring(rings, j)              # side skirt
        f += [[1 + k, 1 + j, o_j], [1 + k, o_j, o_k]]
    m = Mesh(v, np.array(f))
    if m.volume() < 0:
        m.faces = m.faces[:, ::-1]
    return m


def write_stl(path: str, mesh: Mesh) -> None:
    import struct
    with open(path, "wb") as fh:
        fh.write(b"hybrid_core".ljust(80, b" "))
        fh.write(struct.pack("<I", len(mesh.faces)))
        for f in mesh.faces:
            a, b, c = mesh.vertices[f]
            n = np.cross(b - a, c - a)
            ln = np.linalg.norm(n)
            n = n / ln if ln > 0 else n
            fh.write(struct.pack("<12fH", *n, *a, *b, *c, 0))
