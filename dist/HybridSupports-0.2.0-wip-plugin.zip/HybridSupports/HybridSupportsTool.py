# Required Notice: Copyright Matthew Armstrong (https://github.com/The-Dorkknight)
# Licensed under the PolyForm Noncommercial License 1.0.0. No warranty.
#
# Scene-node creation follows the pattern of Cura's own SupportEraser tool
# (Ultimaker B.V., LGPLv3); no code was copied from it.
"""Cura tool: generate hybrid tower supports for the selected model(s)."""

import json
import os
import time
from datetime import datetime
from typing import List, Optional

import numpy

from PyQt6.QtCore import Qt

from UM.Logger import Logger
from UM.Math.Vector import Vector
from UM.Mesh.MeshBuilder import MeshBuilder
from UM.Message import Message
from UM.Operations.AddSceneNodeOperation import AddSceneNodeOperation
from UM.Operations.GroupedOperation import GroupedOperation
from UM.Operations.RemoveSceneNodeOperation import RemoveSceneNodeOperation
from UM.Operations.TranslateOperation import TranslateOperation
from UM.Scene.Iterator.DepthFirstIterator import DepthFirstIterator
from UM.Scene.Selection import Selection
from UM.Settings.SettingInstance import SettingInstance
from UM.Tool import Tool

from cura.CuraApplication import CuraApplication
from cura.Operations.SetParentOperation import SetParentOperation
from cura.Scene.BuildPlateDecorator import BuildPlateDecorator
from cura.Scene.CuraSceneNode import CuraSceneNode
from cura.Scene.SliceableObjectDecorator import SliceableObjectDecorator

from . import hybrid_core as hc

__version__ = hc.__version__


def _buildDate() -> str:
    """Build stamp written by install.py; file time when run from source."""
    here = os.path.dirname(os.path.abspath(__file__))
    try:
        with open(os.path.join(here, "build_info.json"), encoding="utf-8") as fh:
            return str(json.load(fh)["build_date"])
    except Exception:
        return datetime.fromtimestamp(os.path.getmtime(__file__)).strftime("%Y-%m-%d %H:%M") + " dev"


__build_date__ = _buildDate()

TOWER_PREFIX = "HybridTower"
BLOCKER_PREFIX = "HybridBlocker"


class HybridSupportsTool(Tool):
    def __init__(self) -> None:
        super().__init__()
        self._shortcut_key = Qt.Key.Key_H
        self._s = hc.HybridSettings()
        self._status = "Select a model, then press Generate."
        self._last_units = []
        self._support_hint = False
        self.setExposedProperties(
            "HeadMode", "ConeFill", "BridgeGap", "GussetCount", "GussetHeight", "GussetLength",
            "WallLines", "MaxSpan", "ContactGap", "MaxTowerRadius", "UseBlocker",
            "UseCuraAngle", "SupportAngle", "Status", "VersionText",
        )

    # ---------------------------------------------------------------- props
    def _num(self, value, cast=float):
        try:
            return cast(str(value).replace(",", "."))
        except (TypeError, ValueError):
            return None

    def getHeadMode(self) -> str:
        return self._s.head_mode

    def setHeadMode(self, v: str) -> None:
        if v in ("cone", "branch", "trapezoid", "conform") and v != self._s.head_mode:
            self._s.head_mode = v
            self.propertyChanged.emit()

    def getConeFill(self) -> str:
        return self._s.cone_fill

    def setConeFill(self, v: str) -> None:
        if v in ("cross", "rings", "none") and v != self._s.cone_fill:
            self._s.cone_fill = v
            self.propertyChanged.emit()

    def _setter(name, field, cast=float, lo=None, hi=None, scale=1.0):  # noqa: N805
        def setter(self, v):
            x = self._num(v, cast)
            if x is None:
                return
            x = x * scale
            if lo is not None:
                x = max(lo, x)
            if hi is not None:
                x = min(hi, x)
            if getattr(self._s, field) != x:
                setattr(self._s, field, cast(x) if cast is int else x)
                self.propertyChanged.emit()
        setter.__name__ = "set" + name
        return setter

    getBridgeGap = lambda self: self._s.bridge_gap  # noqa: E731
    setBridgeGap = _setter("BridgeGap", "bridge_gap", float, 0.0, 60.0)
    getGussetCount = lambda self: self._s.gusset_count  # noqa: E731
    setGussetCount = _setter("GussetCount", "gusset_count", int, 0, 8)
    getGussetHeight = lambda self: self._s.gusset_height  # noqa: E731
    setGussetHeight = _setter("GussetHeight", "gusset_height", float, 0.0, 100.0)
    getGussetLength = lambda self: self._s.gusset_length  # noqa: E731
    setGussetLength = _setter("GussetLength", "gusset_length", float, 0.0, 50.0)
    getWallLines = lambda self: self._s.wall_lines  # noqa: E731
    setWallLines = _setter("WallLines", "wall_lines", int, 1, 10)
    getMaxSpan = lambda self: self._s.max_span  # noqa: E731
    setMaxSpan = _setter("MaxSpan", "max_span", float, 5.0, 500.0)
    getContactGap = lambda self: self._s.contact_gap  # noqa: E731
    setContactGap = _setter("ContactGap", "contact_gap", float, 0.0, 2.0)
    getMaxTowerRadius = lambda self: self._s.max_tower_radius  # noqa: E731
    setMaxTowerRadius = _setter("MaxTowerRadius", "max_tower_radius", float, 1.0, 30.0)
    getSupportAngle = lambda self: self._s.support_angle  # noqa: E731
    setSupportAngle = _setter("SupportAngle", "support_angle", float, 0.0, 89.0)
    del _setter

    _use_cura_angle = True

    def getUseCuraAngle(self) -> bool:
        return self._use_cura_angle

    def setUseCuraAngle(self, v) -> None:
        v = bool(v)
        if v != self._use_cura_angle:
            self._use_cura_angle = v
            self.propertyChanged.emit()

    def getUseBlocker(self) -> bool:
        return self._s.blocker

    def setUseBlocker(self, v) -> None:
        v = bool(v)
        if v != self._s.blocker:
            self._s.blocker = v
            self.propertyChanged.emit()

    def getStatus(self) -> str:
        return self._status

    def getVersionText(self) -> str:
        return f"Hybrid Supports v{__version__} (Built {__build_date__}) \u2022 WORK IN PROGRESS"

    def _setStatus(self, text: str) -> None:
        self._status = text
        self.propertyChanged.emit()

    # -------------------------------------------------------------- helpers
    def _readCuraSettings(self) -> None:
        stack = CuraApplication.getInstance().getGlobalContainerStack()
        if not stack:
            return
        try:
            nr = int(stack.getExtruderPositionValueWithDefault("support_extruder_nr"))
            ext = stack.extruderList[nr]
        except Exception:  # single-extruder or odd machine definitions
            ext = stack
        def val(key, default=None):
            try:
                v = ext.getProperty(key, "value")
                return default if v is None else v
            except Exception:
                return default
        lw = val("support_line_width")
        if lw:
            self._s.line_width = float(lw)
        self._s.layer_height = float(val("layer_height", 0.2))
        # keep the towers out of the zone Cura strips around the model, so it can't cut them up
        self._s.xy_clearance = float(val("support_xy_distance", 0.7)) + 0.1
        # with no support walls, Cura prints thin support areas only where its infill lines
        # cross them; make branches at least one infill spacing thick so none go missing
        walls = int(val("support_wall_count", 0) or 0)
        spacing = float(val("support_line_distance", 0) or 0)
        self._s.min_branch_thickness = 0.0 if walls > 0 or spacing <= 0 else min(spacing + self._s.line_width, 4.0)
        self._support_hint = walls == 0
        if self._use_cura_angle:
            ang = ext.getProperty("support_angle", "value")
            if ang is not None:
                self._s.support_angle = float(ang)

    @staticmethod
    def _models() -> List[CuraSceneNode]:
        out = []
        for node in Selection.getAllSelectedObjects():
            if node.callDecoration("isGroup"):
                cands = [n for n in DepthFirstIterator(node) if n.getMeshData() and not n.callDecoration("isGroup")]
            else:
                cands = [node]
            for n in cands:
                if n.getMeshData() is None or n.callDecoration("isNonPrintingMesh"):
                    continue
                if n.getName().startswith((TOWER_PREFIX, BLOCKER_PREFIX)):
                    continue
                out.append(n)
        return out

    @staticmethod
    def _worldTriangles(node: CuraSceneNode):
        md = node.getMeshData().getTransformed(node.getWorldTransformation(copy=False))
        v = md.getVertices().astype(numpy.float64)
        f = md.getIndices() if md.hasIndices() else numpy.arange(len(v)).reshape(-1, 3)
        # Cura is Y-up with Z towards the front; the core is Z-up.
        vz = numpy.column_stack([v[:, 0], -v[:, 2], v[:, 1]])
        return vz, f

    @staticmethod
    def _toCuraMesh(mesh: "hc.Mesh"):
        v = mesh.vertices
        vc = numpy.column_stack([v[:, 0], v[:, 2], -v[:, 1]])  # back to Y-up
        centre = (vc.min(axis=0) + vc.max(axis=0)) / 2.0
        mb = MeshBuilder()
        mb.setVertices((vc - centre).astype(numpy.float32))
        mb.setIndices(mesh.faces.astype(numpy.int32))
        mb.calculateNormals()
        return mb.build(), Vector(float(centre[0]), float(centre[1]), float(centre[2]))

    def _makeNode(self, parent: CuraSceneNode, mesh: "hc.Mesh", name: str, setting: str, op: GroupedOperation) -> None:
        md, centre = self._toCuraMesh(mesh)
        node = CuraSceneNode()
        node.setName(name)
        node.setSelectable(True)
        node.setCalculateBoundingBox(True)
        node.setMeshData(md)
        node.calculateBoundingBoxMesh()
        plate = CuraApplication.getInstance().getMultiBuildPlateModel().activeBuildPlate
        node.addDecorator(BuildPlateDecorator(plate))
        node.addDecorator(SliceableObjectDecorator())

        stack = node.callDecoration("getStack")
        top = stack.getTop()
        values = {setting: True}
        if setting == "support_mesh":
            values["support_mesh_drop_down"] = False   # we already built down to the landing
            # some printer profiles (e.g. Elegoo) throw away support pieces under 3 mm^2 per layer,
            # which would leave bits of branches and gussets floating; keep every piece
            values["minimum_support_area"] = 0
        for key, val in values.items():
            inst = SettingInstance(stack.getSettingDefinition(key), top)
            inst.setProperty("value", val)
            inst.resetState()
            top.addInstance(inst)

        root = self.getController().getScene().getRoot()
        op.addOperation(AddSceneNodeOperation(node, root))
        op.addOperation(SetParentOperation(node, parent))
        op.addOperation(TranslateOperation(node, centre, set_position=True))

    def _ours(self, model: CuraSceneNode):
        return [c for c in model.getChildren() if c.getName().startswith((TOWER_PREFIX, BLOCKER_PREFIX))]

    # -------------------------------------------------------------- actions
    def generateSupports(self) -> None:
        models = self._models()
        if not models:
            self._setStatus("Select a model first.")
            return
        self._readCuraSettings()
        t0 = time.perf_counter()
        op = GroupedOperation()
        n_units, notes = 0, []
        self._last_units = []
        for model in models:
            for old in self._ours(model):
                op.addOperation(RemoveSceneNodeOperation(old))
            try:
                v, f = self._worldTriangles(model)
                units = hc.generate(v, f, self._s)
            except Exception as e:  # keep Cura alive whatever the mesh looks like
                Logger.logException("e", "Hybrid Supports failed on %s", model.getName())
                notes.append(f"{model.getName()}: failed ({e})")
                continue
            self._last_units += units
            for u in units:
                n_units += 1
                self._makeNode(model, u.support, f"{TOWER_PREFIX}_{n_units:02d}", "support_mesh", op)
                if u.blocker is not None:
                    self._makeNode(model, u.blocker, f"{BLOCKER_PREFIX}_{n_units:02d}", "anti_overhang_mesh", op)
                notes.extend(u.notes)
        if op.getNumChildrenOperations():
            op.push()
        dt = time.perf_counter() - t0
        msg = f"{n_units} support(s) in {dt:.1f} s"
        short = [u for u in self._last_units if u.coverage < 0.95]
        if short:
            msg += f" \u2022 {len(short)} only partly reached (blocked by the model)"
        if self._support_hint and n_units:
            msg += " \u2022 tip: Support Wall Line Count 1 prints the rings cleaner"
        capped = [n for n in notes if "capped" in n]
        if capped:
            msg += f" \u2022 gusset height capped on {len(capped)}"
        self._setStatus(msg)
        if n_units == 0:
            Message("No overhangs needing support were found at the current support angle.",
                    title="Hybrid Supports", message_type=Message.MessageType.NEUTRAL).show()

    def removeSupports(self) -> None:
        op = GroupedOperation()
        count = 0
        targets = self._models() or [n for n in DepthFirstIterator(self.getController().getScene().getRoot())
                                     if isinstance(n, CuraSceneNode)]
        for model in targets:
            for old in self._ours(model):
                op.addOperation(RemoveSceneNodeOperation(old))
                count += 1
        if count:
            op.push()
        self._setStatus(f"Removed {count} generated mesh(es).")
